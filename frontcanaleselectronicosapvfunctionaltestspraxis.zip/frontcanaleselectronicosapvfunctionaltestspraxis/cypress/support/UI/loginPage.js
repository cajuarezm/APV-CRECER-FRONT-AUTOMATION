export const loginPage = {
    usuario: '#NumeroDocumento',
    button: '.Boton-Ingreso'
}