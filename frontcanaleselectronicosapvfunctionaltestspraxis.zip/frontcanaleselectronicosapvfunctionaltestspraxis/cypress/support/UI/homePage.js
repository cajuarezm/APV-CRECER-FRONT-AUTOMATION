export const homePage = {
    dropdownConsult : "#mnu734 > a",
    consultaAffiliate: "#mnu734 > ul > li:nth-child(1) > a",
    logout: "h6 > a",
    btnAcceptLogout: "#cerrarSesion > div.modal-dialog > div > div.modal-footer > div > div.col-md-3.col-md-offset-6 > a"
}