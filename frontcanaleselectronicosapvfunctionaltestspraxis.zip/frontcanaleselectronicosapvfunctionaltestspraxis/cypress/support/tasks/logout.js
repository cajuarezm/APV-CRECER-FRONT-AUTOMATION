import { homePage } from "../UI/homePage.js"
import { loginPage } from "../UI/loginPage.js"

export default function logout () {
    cy.get(homePage.logout)
        .click( { force: true } )
    cy.get(homePage.btnAcceptLogout)
        .click()
    cy.contains("Login")
    cy.get(loginPage.email)
    cy.get(loginPage.password)
    cy.get(loginPage.button)
}