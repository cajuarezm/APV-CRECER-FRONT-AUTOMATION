import { loginPage } from "../UI/loginPage.js"

export default function login (dui) {
    cy.get(loginPage.usuario)
        .type(dui)
    cy.get(loginPage.button)
        .click()
}