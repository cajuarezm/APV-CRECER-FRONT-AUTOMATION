import login from "../../support/tasks/login"

let advisor
let userInfo

before(() =>{

    cy.fixture('../fixtures/advisor.json')
        .then((fixture) => {
            advisor = fixture
        })
})

When(`Un usuario con credenciales ingresa al sitio de canaleselectronicosapv`, () => {
    cy.visit('/')
    login('035480764')

    }   
)

Then('Debe ver el menu y la pantalla principal Inicio', () => {
   
})