
const cucumber = require('cypress-cucumber-preprocessor').default

const fs = require('fs')
const path = require('path')
const pdf = require('pdf-parse');

const repoRoot = path.join(__dirname, '..', '..') // assumes pdf at project root

module.exports = (on, config) => {
  on('file:preprocessor', cucumber())

  on('task', {
    getPdfContent (pdfName) {
      return (parsePdf(pdfName))
    }
  })
}


const parsePdf = async (pdfName) => {
  const pdfPathname = path.join(repoRoot, pdfName)
  let dataBuffer = fs.readFileSync(pdfPathname);
  return await pdf(dataBuffer)  // use async/await since pdf returns a promise 
}