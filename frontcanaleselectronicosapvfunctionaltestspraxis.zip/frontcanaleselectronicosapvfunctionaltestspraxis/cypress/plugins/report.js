const report = require('multiple-cucumber-html-reporter');

const date = new Date();
const env = require('../../cypress.env');

report.generate({
    jsonDir: './cypress/cucumber-json/',
    reportPath: './report',
    pageTitle: env.projectName + ' Reports',
    reportName: 'Beneficios Report',
    displayDuration: true,
    useCDN: true,
    // metadata:{
    //     browser: {
    //         name: 'chrome',
    //         version: '60'
    //     },
    //     device: 'Test machine',
    //     platform: {
    //         name: 'ubuntu',
    //         version: '16.04'
    //     }
    // },
    customData: {
        title: 'Run info',
        data: [
            {label: 'Project', value: env.projectName},
            {label: 'Release', value: env.projectVersion},
            {label: 'Execution Start Time', value: date.getFullYear()+'-'+( date.getMonth()+1)+'-'+ date.getDate()+ ' '+
            date.getHours() + ":" +  date.getMinutes() + ":" +  date.getSeconds()}
        ]
    }
});
