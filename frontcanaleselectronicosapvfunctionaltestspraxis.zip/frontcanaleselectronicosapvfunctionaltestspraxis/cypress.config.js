const { defineConfig } = require('cypress')

module.exports = defineConfig({
  requestTimeout: 50000,
  responseTimeout: 60000,
  e2e: {
    // We've imported your old cypress plugins here.
    // You may want to clean this up later by importing these.
    setupNodeEvents(on, config) {
      return require('./cypress/plugins/index.js')(on, config)
    },
    baseUrl: 'http://febe01-desa.crecer.com.sv:9888/',
    specPattern: 'cypress/e2e/**/*.feature',
    supportFile:false
  },
})
